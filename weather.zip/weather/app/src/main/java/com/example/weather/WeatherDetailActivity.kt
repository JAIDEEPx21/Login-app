package com.example.weather

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.weather.api.RetrofitClient
import com.example.weather.databinding.ActivityWeatherDetailBinding
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class WeatherDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityWeatherDetailBinding
    private lateinit var dailyForecastAdapter: DailyForecastAdapter
    private val apiKey = "bede9c6b52dd2519d56ad0bce02adf4e"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWeatherDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val city = intent.getStringExtra("CITY_NAME") ?: ""
        if (city.isNotEmpty()) {
            setupRecyclerView()
            fetchWeather(city)
        } else {
            Toast.makeText(this, "No city provided", Toast.LENGTH_SHORT).show()
            finish()
        }

        binding.btnBack.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }
    }

    private fun setupRecyclerView() {
        dailyForecastAdapter = DailyForecastAdapter(emptyList())
        binding.rvDaily.layoutManager = LinearLayoutManager(this)
        binding.rvDaily.adapter = dailyForecastAdapter
    }

    private fun fetchWeather(city: String) {
        lifecycleScope.launch {
            try {
                val weatherResponse = RetrofitClient.instance.getCurrentWeather(city, apiKey)
                if (weatherResponse.isSuccessful && weatherResponse.body() != null) {
                    val weather = weatherResponse.body()!!
                    val tzOffset = weather.timezone
                    
                    binding.tvCityName.text = weather.name
                    binding.tvTemperature.text = "${weather.main.temp.toInt()}°"
                    
                    // Forecast call
                    val forecastResponse = RetrofitClient.instance.getForecast(city, apiKey)
                    if (forecastResponse.isSuccessful && forecastResponse.body() != null) {
                        dailyForecastAdapter.updateData(forecastResponse.body()!!.list, tzOffset)
                    }
                    
                } else {
                    val errorMsg = when(weatherResponse.code()) {
                        401 -> "Invalid API Key."
                        404 -> "City not found"
                        else -> "Error: ${weatherResponse.message()}"
                    }
                    Toast.makeText(this@WeatherDetailActivity, errorMsg, Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@WeatherDetailActivity, "Error: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }
}
