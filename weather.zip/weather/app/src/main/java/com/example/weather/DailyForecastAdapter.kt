package com.example.weather

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.weather.api.ForecastItem
import com.example.weather.databinding.ItemForecastDailyBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class DailyForecastAdapter(
    private var forecastList: List<ForecastItem>,
    private var timezoneOffset: Int = 0
) : RecyclerView.Adapter<DailyForecastAdapter.DailyViewHolder>() {

    class DailyViewHolder(val binding: ItemForecastDailyBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DailyViewHolder {
        val binding = ItemForecastDailyBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return DailyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: DailyViewHolder, position: Int) {
        val item = forecastList[position]
        
        // Day Name
        val daySdf = SimpleDateFormat("EEEE", Locale.getDefault())
        val offsetHours = timezoneOffset / 3600
        val offsetMinutes = (Math.abs(timezoneOffset) % 3600) / 60
        val tzId = String.format("GMT%+03d:%02d", offsetHours, offsetMinutes)
        daySdf.timeZone = TimeZone.getTimeZone(tzId)
        
        val date = Date(item.dt * 1000)
        holder.binding.tvDayName.text = daySdf.format(date)
        
        // Temperature
        holder.binding.tvDailyTemp.text = "${item.main.temp.toInt()}°"
        
        // Icon mapping
        val iconCode = item.weather.firstOrNull()?.icon ?: ""
        val iconRes = when {
            iconCode.startsWith("01") -> R.drawable.ic_weather_sunny
            iconCode.startsWith("02") || iconCode.startsWith("03") || iconCode.startsWith("04") -> R.drawable.ic_weather_cloudy
            iconCode.startsWith("09") || iconCode.startsWith("10") -> R.drawable.ic_weather_rainy
            else -> R.drawable.ic_weather_cloudy
        }
        holder.binding.ivDailyIcon.setImageResource(iconRes)
    }

    override fun getItemCount(): Int = forecastList.size

    fun updateData(newList: List<ForecastItem>, newOffset: Int) {
        // Group by day to show only one entry per day
        val grouped = newList.groupBy { 
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val offsetHours = newOffset / 3600
            val offsetMinutes = (Math.abs(newOffset) % 3600) / 60
            val tzId = String.format("GMT%+03d:%02d", offsetHours, offsetMinutes)
            sdf.timeZone = TimeZone.getTimeZone(tzId)
            sdf.format(Date(it.dt * 1000))
        }.values.map { it.first() } // Take first reading for each day
        
        forecastList = grouped
        timezoneOffset = newOffset
        notifyDataSetChanged()
    }
}
