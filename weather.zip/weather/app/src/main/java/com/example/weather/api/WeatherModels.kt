package com.example.weather.api

import com.google.gson.annotations.SerializedName

data class CurrentWeather(
    @SerializedName("main") val main: Main,
    @SerializedName("weather") val weather: List<Weather>,
    @SerializedName("wind") val wind: Wind,
    @SerializedName("name") val name: String,
    @SerializedName("sys") val sys: Sys,
    @SerializedName("coord") val coord: Coord,
    @SerializedName("timezone") val timezone: Int // Offset in seconds
)

data class ForecastResponse(
    @SerializedName("list") val list: List<ForecastItem>,
    @SerializedName("city") val city: City
)

data class ForecastItem(
    @SerializedName("dt") val dt: Long,
    @SerializedName("dt_txt") val dtTxt: String,
    @SerializedName("main") val main: Main,
    @SerializedName("weather") val weather: List<Weather>,
    @SerializedName("pop") val pop: Double
)

data class City(
    @SerializedName("timezone") val timezone: Int
)

data class Main(
    @SerializedName("temp") val temp: Double,
    @SerializedName("feels_like") val feelsLike: Double,
    @SerializedName("temp_min") val tempMin: Double,
    @SerializedName("temp_max") val tempMax: Double,
    @SerializedName("humidity") val humidity: Int,
    @SerializedName("pressure") val pressure: Int
)

data class Weather(
    @SerializedName("main") val main: String,
    @SerializedName("description") val description: String,
    @SerializedName("icon") val icon: String
)

data class Wind(
    @SerializedName("speed") val speed: Double,
    @SerializedName("deg") val deg: Int
)

data class Sys(
    @SerializedName("sunrise") val sunrise: Long,
    @SerializedName("sunset") val sunset: Long
)

data class Coord(
    @SerializedName("lat") val lat: Double,
    @SerializedName("lon") val lon: Double
)

// Air Quality Models
data class AirQualityResponse(
    @SerializedName("list") val list: List<AirQualityItem>
)

data class AirQualityItem(
    @SerializedName("main") val main: AqiMain
)

data class AirQualityMain(
    @SerializedName("aqi") val aqi: Int
)

// Use a wrapper class to avoid name collision or just rename
data class AqiMain(
    @SerializedName("aqi") val aqi: Int
)
