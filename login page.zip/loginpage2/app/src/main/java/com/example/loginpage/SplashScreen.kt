package com.example.loginpage

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SplashScreen(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        // Background Glow
        Box(
            modifier = Modifier
                .size(500.dp)
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color(0xFFE46B2C).copy(alpha = 0.25f),
                            Color(0xFF4B2000).copy(alpha = 0.1f),
                            Color.Transparent
                        )
                    )
                )
        )

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Logo(modifier = Modifier.size(180.dp))

            Spacer(modifier = Modifier.height(40.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = stringResource(id = R.string.pixel),
                    color = Color.White,
                    fontSize = 42.sp,
                    fontWeight = FontWeight.Light,
                    letterSpacing = 2.sp
                )
                Text(
                    text = stringResource(id = R.string.forge),
                    color = Color(0xFFE46B2C),
                    fontSize = 42.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.width(320.dp)
            ) {
                HorizontalDivider(
                    color = Color(0xFFE46B2C),
                    modifier = Modifier.weight(1f),
                    thickness = 2.5.dp
                )
                Text(
                    text = stringResource(id = R.string.studios),
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Normal,
                    letterSpacing = 6.sp,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
                HorizontalDivider(
                    color = Color(0xFFE46B2C),
                    modifier = Modifier.weight(1f),
                    thickness = 2.5.dp
                )
            }
        }

        // Next Button at Bottom Right
        FloatingActionButton(
            onClick = { /* TODO: Navigate to next screen */ },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(32.dp),
            containerColor = Color(0xFFE46B2C),
            contentColor = Color.White,
            shape = MaterialTheme.shapes.medium
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = "Next"
            )
        }
    }
}

@Composable
fun Logo(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        // Vertical hammer handle / stem of P
        drawRect(
            color = Color(0xFF241D18),
            topLeft = Offset(w * 0.43f, h * 0.38f),
            size = Size(w * 0.10f, h * 0.42f)
        )

        // Hammer head top (more blocky)
        drawRect(
            color = Color(0xFF332A24),
            topLeft = Offset(w * 0.38f, h * 0.33f),
            size = Size(w * 0.15f, h * 0.10f)
        )

        // The Curved "Fire" part of the P - more fragmented/pixelated look
        val firePath = Path().apply {
            moveTo(w * 0.53f, h * 0.35f)
            cubicTo(
                w * 0.82f, h * 0.35f,
                w * 0.82f, h * 0.65f,
                w * 0.53f, h * 0.65f
            )
            lineTo(w * 0.53f, h * 0.55f)
            cubicTo(
                w * 0.72f, h * 0.55f,
                w * 0.72f, h * 0.45f,
                w * 0.53f, h * 0.45f
            )
            close()
        }

        drawPath(
            path = firePath,
            brush = Brush.verticalGradient(
                colors = listOf(Color(0xFFFFB74D), Color(0xFFE46B2C))
            ),
            style = Fill
        )

        // Add small pixel blocks to make it look "forged" and pixelated
        val sparkColor = Color(0xFFE46B2C)
        val accentColor = Color(0xFFFFD54F)

        // Sparks along the curve
        drawRect(sparkColor, Offset(w * 0.78f, h * 0.38f), Size(10f, 10f))
        drawRect(accentColor, Offset(w * 0.81f, h * 0.44f), Size(8f, 8f))
        drawRect(sparkColor, Offset(w * 0.76f, h * 0.58f), Size(12f, 12f))
        drawRect(accentColor, Offset(w * 0.70f, h * 0.64f), Size(6f, 6f))

        // Flying sparks
        drawRect(accentColor, Offset(w * 0.65f, h * 0.25f), Size(8f, 8f))
        drawRect(sparkColor, Offset(w * 0.85f, h * 0.32f), Size(6f, 6f))
        drawRect(accentColor, Offset(w * 0.88f, h * 0.50f), Size(10f, 10f))
        drawRect(sparkColor, Offset(w * 0.60f, h * 0.75f), Size(8f, 8f))
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val colorScheme = darkColorScheme(
        primary = Color(0xFFE46B2C),
        background = Color.Black,
        surface = Color.Black
    )
    MaterialTheme(
        colorScheme = colorScheme,
        content = content
    )
}

@Preview(showBackground = true)
@Composable
fun SplashScreenPreview() {
    AppTheme {
        SplashScreen()
    }
}
